import Foundation
import Security

// Exercise the actual networking and session code without real accounts or outbound requests.
private enum Reply {
    case json([String: Any], Int = 200)
    case failure
}

private final class StubProtocol: URLProtocol {
    static var responder: (URLRequest) -> Reply = { _ in .json(["code": 200]) }
    override class func canInit(with request: URLRequest) -> Bool {
        request.url?.host == "app.folia-api.top"
    }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        switch Self.responder(request) {
        case .failure:
            client?.urlProtocol(self, didFailWithError: URLError(.timedOut))
        case .json(let object, let status):
            let response = HTTPURLResponse(url: request.url!, statusCode: status,
                httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try! JSONSerialization.data(withJSONObject: object))
            client?.urlProtocolDidFinishLoading(self)
        }
    }
    override func stopLoading() {}
}

private struct CheckFailure: Error { let text: String }

@main
private struct AccountRegression {
    static func expect(_ condition: Bool, _ text: String) throws {
        if !condition { throw CheckFailure(text: text) }
    }

    static let profile: [String: Any] = ["userId": 12345, "nickname": "Fixture user", "vipType": 0]

    static func fixture(_ request: URLRequest) -> Reply {
        let path = request.url!.path
        if path.hasSuffix("/login/qr/key") {
            return .json(["code": 200, "data": ["code": 200, "unikey": "fixture-key"],
                "cookie": "DEVICE=fixture-device"])
        }
        if path.hasSuffix("/login/qr/create") {
            return .json(["code": 200, "data": ["qrimg": "data:image/png;base64,AA=="]])
        }
        if path.hasSuffix("/login/qr/check") {
            return .json(["code": 803, "cookie": "MUSIC_U=fixture-login; __csrf=fixture-csrf"])
        }
        if path.hasSuffix("/user/account") { return .json(["code": 200, "profile": profile]) }
        if path.hasSuffix("/login/status") { return .json(["code": 200, "data": ["profile": profile]]) }
        return .json(["code": 200, "result": [], "playlist": [], "data": []])
    }

    static func authenticate(_ api: NeteaseAPI) async throws {
        _ = try await api.qrKey()
        switch await api.checkQR(key: "fixture-key") {
        case .confirmed: return
        default: throw CheckFailure(text: "fixture QR should authenticate")
        }
    }

    @MainActor static func main() async {
        URLProtocol.registerClass(StubProtocol.self)
        let api = NeteaseAPI.shared
        var failures = 0
        let cases: [(String, () async throws -> Void)] = [
            ("account fallback survives a transport failure", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/status") { return .failure }
                    return fixture(request)
                }
                let account = try await api.currentAccount()
                try expect(account?.userId == 12345, "a valid native account must survive a failed status endpoint")
            }),
            ("QR session sends its device cookie", {
                var carriedCookie = false
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/create") {
                        let values = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
                        carriedCookie = values.contains { $0.name == "cookie" && $0.value?.contains("DEVICE=fixture-device") == true }
                    }
                    return fixture(request)
                }
                let key = try await api.qrKey()
                _ = try await api.qrImage(key: key)
                try expect(carriedCookie, "the device cookie obtained by qr/key was dropped before qr/create")
            }),
            ("QR success requires an authenticated cookie", {
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/check") {
                        return .json(["code": 803, "cookie": "os=pc; appver=2.9.7"])
                    }
                    return fixture(request)
                }
                _ = try await api.qrKey()
                if case .confirmed = await api.checkQR(key: "fixture-key") {
                    throw CheckFailure(text: "device-only cookie was accepted as a login credential")
                }
                try expect(!(await api.isSignedIn), "a failed credential exchange must not mark the API signed in")
            }),
            ("a new QR excludes old account credentials", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                var oldCookieSent = false
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/key") {
                        let values = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
                        oldCookieSent = values.contains { $0.name == "cookie" && $0.value?.contains("MUSIC_U=") == true }
                    }
                    return fixture(request)
                }
                _ = try await api.qrKey()
                try expect(!oldCookieSent, "old account credentials leaked into a new QR session")
            }),
            ("temporary account errors preserve the signed-in library", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                let library = LibraryStore()
                await library.refresh()
                try expect(library.account?.userId == 12345, "initial account load failed")
                StubProtocol.responder = { request in
                    let path = request.url!.path
                    if path.hasSuffix("/login/status") || path.hasSuffix("/user/account") { return .failure }
                    return fixture(request)
                }
                await library.refresh()
                try expect(library.account?.userId == 12345, "a temporary network error silently logged the user out")
            })
        ]
        for (name, run) in cases {
            await api.signOut()
            do {
                try await run()
                print("PASS: \(name)")
            } catch {
                failures += 1
                let reason = (error as? CheckFailure)?.text ?? String(describing: type(of: error))
                print("FAIL: \(name): \(reason)")
            }
        }
        await api.signOut()
        print("Regression cases: \(cases.count), failures: \(failures)")
        if failures > 0 { exit(1) }
    }
}
