import Foundation
import Security

// Exercise the actual networking and session code without real accounts or outbound requests.
private enum Reply {
    case json([String: Any], Int = 200)
    case failure
    case held
}

private final class StubProtocol: URLProtocol {
    static var responder: (URLRequest) -> Reply = { _ in .json(["code": 200]) }
    static var holdStarted: AsyncStream<StubProtocol>.Continuation?
    override class func canInit(with request: URLRequest) -> Bool {
        request.url?.host == "app.folia-api.top"
    }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        switch Self.responder(request) {
        case .held:
            Self.holdStarted?.yield(self)
            Self.holdStarted?.finish()
        case .failure:
            client?.urlProtocol(self, didFailWithError: URLError(.timedOut))
        case .json(let object, let status):
            finish(object, status: status)
        }
    }
    func finish(_ object: [String: Any], status: Int = 200) {
        let response = HTTPURLResponse(url: request.url!, statusCode: status,
            httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: try! JSONSerialization.data(withJSONObject: object))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

private struct CheckFailure: Error { let text: String }

@main
private struct AccountRegression {
    static func expect(_ condition: Bool, _ text: String) throws {
        if !condition { throw CheckFailure(text: text) }
    }

    static let profile: [String: Any] = ["userId": 12345, "nickname": "Fixture user", "vipType": 0]

    static func fixture(_ request: URLRequest) -> Reply {
        let path = request.url!.path
        if path.hasSuffix("/login/qr/key") {
            return .json(["code": 200, "data": ["code": 200, "unikey": "fixture-key"],
                "cookie": "DEVICE=fixture-device"])
        }
        if path.hasSuffix("/login/qr/create") {
            return .json(["code": 200, "data": ["qrimg": "data:image/png;base64,AA=="]])
        }
        if path.hasSuffix("/login/qr/check") {
            return .json(["code": 803, "cookie": "MUSIC_U=fixture-login; __csrf=fixture-csrf"])
        }
        if path.hasSuffix("/user/account") { return .json(["code": 200, "profile": profile]) }
        if path.hasSuffix("/login/status") { return .json(["code": 200, "data": ["profile": profile]]) }
        return .json(["code": 200, "result": [], "playlist": [], "data": []])
    }

    static func authenticate(_ api: NeteaseAPI) async throws {
        _ = try await api.qrKey()
        switch await api.checkQR(key: "fixture-key") {
        case .confirmed: return
        default: throw CheckFailure(text: "fixture QR should authenticate")
        }
    }

    @MainActor static func main() async {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [StubProtocol.self]
        let api = NeteaseAPI(session: URLSession(configuration: configuration))
        var failures = 0
        let cases: [(String, () async throws -> Void)] = [
            ("account fallback survives a transport failure", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/status") { return .failure }
                    return fixture(request)
                }
                let account = try await api.currentAccount()
                try expect(account?.userId == 12345, "a valid native account must survive a failed status endpoint")
            }),
            ("QR session sends its device cookie", {
                var carriedCookie = false
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/create") {
                        let values = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
                        carriedCookie = values.contains { $0.name == "cookie" && $0.value?.contains("DEVICE=fixture-device") == true }
                    }
                    return fixture(request)
                }
                let key = try await api.qrKey()
                _ = try await api.qrImage(key: key)
                try expect(carriedCookie, "the device cookie obtained by qr/key was dropped before qr/create")
            }),
            ("QR success requires an authenticated cookie", {
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/check") {
                        return .json(["code": 803, "cookie": "os=pc; appver=2.9.7"])
                    }
                    return fixture(request)
                }
                _ = try await api.qrKey()
                if case .confirmed = await api.checkQR(key: "fixture-key") {
                    throw CheckFailure(text: "device-only cookie was accepted as a login credential")
                }
                try expect(!(await api.isSignedIn), "a failed credential exchange must not mark the API signed in")
            }),
            ("a new QR excludes old account credentials", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                var oldCookieSent = false
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/qr/key") {
                        let values = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
                        oldCookieSent = values.contains { $0.name == "cookie" && $0.value?.contains("MUSIC_U=") == true }
                    }
                    return fixture(request)
                }
                _ = try await api.qrKey()
                try expect(!oldCookieSent, "old account credentials leaked into a new QR session")
            }),
            ("temporary account errors preserve the signed-in library", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                let library = LibraryStore(api: api)
                await library.refresh()
                try expect(library.account?.userId == 12345, "initial account load failed")
                StubProtocol.responder = { request in
                    let path = request.url!.path
                    if path.hasSuffix("/login/status") || path.hasSuffix("/user/account") { return .failure }
                    return fixture(request)
                }
                await library.refresh()
                try expect(library.account?.userId == 12345, "a temporary network error silently logged the user out")
            }),
            ("native account failure still tries the normal status endpoint", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/user/account") { return .failure }
                    return fixture(request)
                }
                let account = try await api.currentAccount()
                try expect(account?.userId == 12345, "the secondary account endpoint was skipped")
            }),
            ("confirmed invalid credentials clear the session", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    let path = request.url!.path
                    if path.hasSuffix("/user/account") || path.hasSuffix("/login/status") {
                        return .json(["code": 301])
                    }
                    return fixture(request)
                }
                let account = try await api.currentAccount()
                try expect(account == nil, "a confirmed invalid credential must not restore an account")
                try expect(!(await api.isSignedIn), "invalid credentials were retained as signed in")
            }),
            ("explicit successful empty profiles clear expired credentials", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    let path = request.url!.path
                    if path.hasSuffix("/user/account") {
                        return .json(["code": 200, "profile": NSNull(), "account": NSNull()])
                    }
                    if path.hasSuffix("/login/status") {
                        return .json(["code": 200, "data": ["code": 200, "profile": NSNull(), "account": NSNull()]])
                    }
                    return fixture(request)
                }
                let account = try await api.currentAccount()
                try expect(account == nil, "two explicitly logged-out results should return no account")
                try expect(!(await api.isSignedIn), "an expired credential remained stuck in account retry")
            }),
            ("edge HTTP 403 must not clear an authenticated session", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    let path = request.url!.path
                    if path.hasSuffix("/user/account") || path.hasSuffix("/login/status") {
                        return .json(["message": "synthetic edge rejection"], 403)
                    }
                    return fixture(request)
                }
                do {
                    _ = try await api.currentAccount()
                    throw CheckFailure(text: "a transport failure was silently treated as logout")
                } catch is NeteaseAPI.APIError { }
                try expect(await api.isSignedIn, "edge HTTP 403 erased the login credential")
            }),
            ("a stale account lookup cannot erase a new QR login", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                let heldRequests = AsyncStream<StubProtocol> { continuation in
                    StubProtocol.holdStarted = continuation
                }
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/user/account") { return .held }
                    return fixture(request)
                }
                let pending = Task { try await api.currentAccount() }
                var held: StubProtocol?
                for await request in heldRequests { held = request; break }
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/login/status") { return .json(["code": 301]) }
                    if request.url!.path.hasSuffix("/login/qr/check") {
                        return .json(["code": 803, "cookie": "MUSIC_U=fixture-new-login"])
                    }
                    return fixture(request)
                }
                try await authenticate(api)
                held!.finish(["code": 301])
                do {
                    _ = try await pending.value
                    throw CheckFailure(text: "a stale lookup was accepted after the session changed")
                } catch is CancellationError { }
                try expect(await api.isSignedIn, "the old account lookup erased the new login")
                StubProtocol.holdStarted = nil
            }),
            ("authenticated playlists work while the normal proxy is offline", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path == "/api/native/netease/user/playlist" {
                        return .json(["code": 200, "playlist": [["id": 456, "name": "Fixture playlist", "trackCount": 1]]])
                    }
                    if request.url!.path == "/api/netease/user/playlist" { return .failure }
                    return fixture(request)
                }
                let playlists = try await api.userPlaylists(userId: 12345)
                try expect(playlists.count == 1 && playlists.first?.id == 456, "the available native playlist endpoint was not used")
            }),
            ("native risk responses fall back to valid proxy playlists", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path == "/api/native/netease/user/playlist" {
                        return .json(["code": -462, "message": "synthetic risk rejection"])
                    }
                    if request.url!.path == "/api/netease/user/playlist" {
                        return .json(["code": 200, "playlist": [["id": 789, "name": "Proxy fixture"]]])
                    }
                    return fixture(request)
                }
                let playlists = try await api.userPlaylists(userId: 12345)
                try expect(playlists.first?.id == 789, "a risk response was accepted as an empty library")
            }),
            ("switching accounts clears the previous library on fetch failure", {
                StubProtocol.responder = fixture
                try await authenticate(api)
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/user/playlist") {
                        return .json(["code": 200, "playlist": [["id": 111, "name": "First account fixture"]]])
                    }
                    return fixture(request)
                }
                let library = LibraryStore(api: api)
                await library.refresh()
                try expect(library.collections.first?.id == 111, "first account fixture did not load")
                StubProtocol.responder = { request in
                    if request.url!.path.hasSuffix("/user/account") {
                        return .json(["code": 200, "profile": ["userId": 67890, "nickname": "Second fixture"]])
                    }
                    if request.url!.path.hasSuffix("/user/playlist") { return .failure }
                    return fixture(request)
                }
                await library.refresh()
                try expect(library.account?.userId == 67890, "second account did not load")
                try expect(library.collections.isEmpty, "the second account displayed the first account's library")
            })
        ]
        for (name, run) in cases {
            await api.signOut()
            do {
                try await run()
                print("PASS: \(name)")
            } catch {
                failures += 1
                let reason = (error as? CheckFailure)?.text ?? String(describing: type(of: error))
                print("FAIL: \(name): \(reason)")
            }
        }
        await api.signOut()
        print("Regression cases: \(cases.count), failures: \(failures)")
        if failures > 0 { exit(1) }
    }
}
