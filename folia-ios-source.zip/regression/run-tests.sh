#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$(mktemp -d)"
trap 'rm -rf "$DEST"' EXIT
xcrun swiftc -swift-version 5 -target "$(uname -m)-apple-macosx13.0" -parse-as-library \
  "$ROOT/ios-native/Sources/Core/Models.swift" \
  "$ROOT/ios-native/Sources/Core/LyricParser.swift" \
  "$ROOT/ios-native/Sources/Core/NeteaseAPI.swift" \
  "$ROOT/ios-native/Sources/State/LibraryStore.swift" \
  "$ROOT/regression/AccountRegression.swift" \
  -o "$DEST/account-regression"
"$DEST/account-regression"
