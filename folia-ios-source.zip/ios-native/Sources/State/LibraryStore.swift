import SwiftUI

/// 全局会话状态：登录账号、首页歌单、各个数据页的加载态。
@MainActor
final class LibraryStore: ObservableObject {
    private let api: NeteaseAPI

    init(api: NeteaseAPI = .shared) {
        self.api = api
    }
    @Published private(set) var account: Account?
    @Published private(set) var collections: [MusicCollection] = []
    @Published private(set) var isLoading = false
    @Published var message: String?

    var isSignedIn: Bool { account != nil }

    func refresh() async {
        isLoading = true
        defer { isLoading = false }

        do {
            account = try await api.currentAccount()
            message = nil
        } catch {
            // 暂时断网或接口风控不代表退出登录，保留已有账号和曲库。
            if !(error is CancellationError) {
                message = (error as? LocalizedError)?.errorDescription ?? "账号暂时无法刷新，请稍后重试。"
            }
            return
        }
        guard let account else {
            collections = (try? await api.recommendedPlaylists()) ?? []
            return
        }
        let playlists = (try? await api.userPlaylists(userId: account.userId)) ?? []
        let albums = (try? await api.userAlbums()) ?? []
        collections = playlists + albums
    }

    func signOut() async {
        await api.signOut()
        account = nil
        await refresh()
    }

    func signIn(session account: Account) {
        self.account = account
        Task { await refresh() }
    }
}
