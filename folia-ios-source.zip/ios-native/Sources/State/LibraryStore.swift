import SwiftUI

/// 全局会话状态：登录账号、首页歌单、各个数据页的加载态。
@MainActor
final class LibraryStore: ObservableObject {
    private let api: NeteaseAPI
    private var refreshGeneration = 0

    init(api: NeteaseAPI = .shared) {
        self.api = api
    }
    @Published private(set) var account: Account?
    @Published private(set) var collections: [MusicCollection] = []
    @Published private(set) var isLoading = false
    @Published var message: String?

    var isSignedIn: Bool { account != nil }

    func refresh() async {
        refreshGeneration &+= 1
        let generation = refreshGeneration
        isLoading = true
        defer { if generation == refreshGeneration { isLoading = false } }

        do {
            let refreshedAccount = try await api.currentAccount()
            guard generation == refreshGeneration else { return }
            if account?.userId != refreshedAccount?.userId { collections = [] }
            account = refreshedAccount
            message = nil
        } catch {
            guard generation == refreshGeneration else { return }
            // 暂时断网或接口风控不代表退出登录，保留已有账号和曲库。
            if !(error is CancellationError) {
                message = (error as? LocalizedError)?.errorDescription ?? "账号暂时无法刷新，请稍后重试。"
            }
            return
        }
        guard let account else {
            let recommendations = (try? await api.recommendedPlaylists()) ?? []
            guard generation == refreshGeneration else { return }
            collections = recommendations
            return
        }
        let playlists: [MusicCollection]
        do {
            playlists = try await api.userPlaylists(userId: account.userId)
        } catch {
            guard generation == refreshGeneration else { return }
            message = (error as? LocalizedError)?.errorDescription ?? "歌单暂时无法刷新。"
            return
        }
        guard generation == refreshGeneration else { return }
        // 先显示已取到的歌单；收藏专辑接口慢或离线时，不应让整个首页空等。
        collections = playlists
        let albums = (try? await api.userAlbums()) ?? []
        guard generation == refreshGeneration else { return }
        collections = playlists + albums
    }

    func signOut() async {
        refreshGeneration &+= 1
        account = nil
        collections = []
        await api.signOut()
        await refresh()
    }

    func signIn(session account: Account) {
        refreshGeneration &+= 1
        if self.account?.userId != account.userId { collections = [] }
        self.account = account
        Task { await refresh() }
    }
}
