import Foundation
import Security

/// 直接访问线上 API，等价于原版前端的 fetchWithCreds（src/services/onlineMusic/netease/netease.ts）：
/// 基础地址 https://app.folia-api.top/api/netease，登录态用一个 cookie 字符串走 `?cookie=` 查询参数，
/// 响应体照旧是 { code, data | songs | playlist ... } 的原样 JSON。
///
/// 原版之所以在 iOS 壳里跑一个本地 HTTP 服务器，是因为 WKWebView 里 fetch 有 CORS 与 cookie 限制；
/// 原生 URLSession 没有这两条约束，代理层可以整个去掉。
actor NeteaseAPI {
    static let shared = NeteaseAPI()

    private let base = "https://app.folia-api.top/api/netease"
    /// 纯 weapi 的兜底路由：不依赖家用/服务器隧道，机房 IP 上登录后取账号要用它
    private let nativeBase = "https://app.folia-api.top/api/native/netease"
    private let session: URLSession
    private var qrSessionCookie: String?
    private var activeQRKey: String?
    private var qrNetworkFailures = 0
    private var sessionRevision = 0

    /// 登录态：网易云 `/login/qr/check` 在 803 时回的 cookie 串
    private var signInCookie: String? {
        didSet {
            sessionRevision &+= 1
            Keychain.set(signInCookie, for: Self.cookieKey)
        }
    }
    /// 未登录时用匿名 cookie 访问公开接口（与前端 anonymous_cookie 一致）
    private var anonymousCookie: String? {
        didSet { UserDefaults.standard.set(anonymousCookie, forKey: Self.anonKey) }
    }

    private static let cookieKey = "folia.netease.cookie"
    private static let anonKey = "folia.netease.anonymousCookie"
    /// 匿名注册失败后的冷却时间，避免每次请求都去打一个已经挂掉的路由
    private var anonRetryAfter: Date?

    init(session suppliedSession: URLSession? = nil) {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 90
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.httpCookieAcceptPolicy = .never
        session = suppliedSession ?? URLSession(configuration: config)
        signInCookie = Keychain.get(Self.cookieKey)
        anonymousCookie = UserDefaults.standard.string(forKey: Self.anonKey)
    }

    var isSignedIn: Bool { signInCookie != nil }

    func signOut() {
        signInCookie = nil
        anonymousCookie = nil
        qrSessionCookie = nil
        activeQRKey = nil
    }

    // MARK: - 基础请求

    struct APIError: LocalizedError {
        let code: Int?
        let message: String
        let httpStatus: Int?
        init(code: Int?, message: String, httpStatus: Int? = nil) {
            self.code = code
            self.message = message
            self.httpStatus = httpStatus
        }
        var errorDescription: String? { message }
    }

    /// 发一个 GET，返回原始 JSON 对象。`needsTimestamp` 对应原版对 login/user/playlist-detail 的去缓存处理。
    @discardableResult
    func get(
        _ route: String,
        query: [String: String] = [:],
        needsTimestamp: Bool = false,
        allowAnonymous: Bool = true
    ) async throws -> [String: Any] {
        if allowAnonymous, signInCookie == nil, anonymousCookie == nil {
            await registerAnonymous()
        }

        return try await requestJSON(route, baseURL: base, query: query,
            cookie: signInCookie ?? (allowAnonymous ? anonymousCookie : nil),
            needsTimestamp: needsTimestamp)
    }

    /// 所有请求统一校验 HTTP/JSON；不把响应正文或带凭据的 URL 写进错误信息。
    private func requestJSON(
        _ route: String, baseURL: String, query: [String: String] = [:],
        cookie: String? = nil, needsTimestamp: Bool = true
    ) async throws -> [String: Any] {
        guard var components = URLComponents(string: baseURL + route) else {
            throw APIError(code: nil, message: "bad route \(route)")
        }
        var parameters = query
        if needsTimestamp {
            parameters["timestamp"] = String(Int(Date().timeIntervalSince1970 * 1000))
        }
        if let cookie, !cookie.isEmpty {
            parameters["cookie"] = cookie
        }
        components.queryItems = parameters.sorted { $0.key < $1.key }
            .map { URLQueryItem(name: $0.key, value: $0.value) }

        guard let url = components.url else {
            throw APIError(code: nil, message: "bad url for \(route)")
        }
        var request = URLRequest(url: url)
        request.setValue("https://app.folia-api.top", forHTTPHeaderField: "Referer")
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.httpShouldHandleCookies = false

        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else {
            throw APIError(code: nil, message: "no response")
        }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError(code: nil, message: "接口连接失败（HTTP \(http.statusCode)），请稍后重试。", httpStatus: http.statusCode)
        }
        guard var json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
            throw APIError(code: nil, message: "接口没有返回有效 JSON，请稍后重试。")
        }
        var cookieParts = [json["cookie"] as? String ?? ""]
        let fields = http.allHeaderFields.reduce(into: [String: String]()) { result, item in
            result[String(describing: item.key)] = String(describing: item.value)
        }
        cookieParts += HTTPCookie.cookies(withResponseHeaderFields: fields, for: url)
            .map { "\($0.name)=\($0.value)" }
        let responseCookie = Self.cleanCookie(cookieParts.joined(separator: "; "))
        if !responseCookie.isEmpty { json["cookie"] = responseCookie }
        if let code = Self.responseCode(json), [301, 401, 403, 500, 502, 503, 504].contains(code) {
            throw APIError(code: code, message: "接口返回 code \(code)，请稍后重试。")
        }
        return json
    }

    /// 直接打原生兜底路由（/api/native/netease），不走隧道、不带匿名 cookie
    private func getNative(_ route: String, query: [String: String] = [:]) async throws -> [String: Any] {
        try await requestJSON(route, baseURL: nativeBase, query: query, cookie: signInCookie)
    }

    private static func responseCode(_ json: [String: Any]) -> Int? {
        (json["code"] as? NSNumber)?.intValue ?? (json["code"] as? String).flatMap(Int.init)
    }

    private static func cleanCookie(_ text: String) -> String {
        let attributes: Set<String> = ["path", "domain", "expires", "max-age", "samesite", "secure", "httponly"]
        var pairs: [String: String] = [:]
        for segment in text.split(separator: ";") {
            let pair = segment.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            guard pair.count == 2 else { continue }
            let name = pair[0].trimmingCharacters(in: .whitespacesAndNewlines)
            let value = pair[1].trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, !value.isEmpty, !attributes.contains(name.lowercased()) else { continue }
            pairs[name] = value
        }
        return pairs.keys.sorted().map { "\($0)=\(pairs[$0]!)" }.joined(separator: "; ")
    }

    private static func hasLoginCookie(_ cookie: String) -> Bool {
        cookie.split(separator: ";").contains {
            let pair = $0.trimmingCharacters(in: .whitespaces).split(separator: "=", maxSplits: 1)
            return pair.count == 2 && pair[0] == "MUSIC_U" && !pair[1].isEmpty
        }
    }

    /// 匿名 cookie：不登录也能读公开歌单、搜索
    private func registerAnonymous() async {
        // 上游这个路由会间歇性 503（netease backend offline）。失败要退避，
        // 否则每个接口调用都会先白等一次，首页会空着。
        if let until = anonRetryAfter, Date() < until { return }
        guard let url = URL(string: "\(base)/register/anonimous") else { return }
        guard let (data, _) = try? await session.data(from: url),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let cookie = json["cookie"] as? String, !cookie.isEmpty else {
            anonRetryAfter = Date().addingTimeInterval(120)
            return
        }
        anonymousCookie = cookie
        anonRetryAfter = nil
    }

    // MARK: - 账号与扫码登录

    /// 当前登录状态；未登录（或 cookie 已失效）返回 nil
    func currentAccount() async throws -> Account? {
        guard let credential = signInCookie else { return nil }
        let revision = sessionRevision
        var invalidResponses = 0
        var lastError: Error = APIError(code: nil, message: "账号资料暂时无法读取，登录凭据已保留。")
        // 原生账号接口不依赖临时隧道。任一接口抛错仍尝试另一条，不能在首个超时处退出。
        for native in [true, false] {
            guard revision == sessionRevision else { throw CancellationError() }
            do {
                let json = try await (native
                    ? requestJSON("/user/account", baseURL: nativeBase, cookie: credential)
                    : requestJSON("/login/status", baseURL: base, cookie: credential))
                guard revision == sessionRevision else { throw CancellationError() }
                let envelope = json["data"] as? [String: Any] ?? json
                if let profile = envelope["profile"] as? [String: Any],
                   let id = (profile["userId"] as? NSNumber)?.intValue, id > 0 {
                    return Self.account(from: profile)
                }
                let code = Self.responseCode(envelope) ?? Self.responseCode(json)
                if let code, [301, 401, 403].contains(code) { invalidResponses += 1 }
                if code == 200, envelope["profile"] is NSNull,
                   envelope["account"] == nil || envelope["account"] is NSNull {
                    invalidResponses += 1
                }
                lastError = APIError(code: code,
                    message: "账号资料未返回（code \(code.map(String.init) ?? "none")），可直接重试读取账号。")
            } catch {
                guard revision == sessionRevision else { throw CancellationError() }
                if error is CancellationError { throw error }
                if let code = (error as? APIError)?.code, [301, 401, 403].contains(code) {
                    invalidResponses += 1
                }
                lastError = error
            }
        }
        if invalidResponses == 2 {
            signInCookie = nil
            return nil
        }
        throw lastError
    }

    private static func account(from raw: [String: Any]) -> Account {
        Account(
            userId: (raw["userId"] as? NSNumber)?.intValue ?? (raw["id"] as? NSNumber)?.intValue ?? 0,
            nickname: raw["nickname"] as? String ?? "",
            avatarUrl: raw["avatarUrl"] as? String,
            vipType: (raw["vipType"] as? NSNumber)?.intValue
        )
    }

    /// 扫码第一步：拿 key
    /// 部分后端会在响应顶层附带设备 cookie，后续 create/check 必须携带；
    /// 未附带 cookie 时也保持本次扫码与已登录账号相互隔离。
    func qrKey() async throws -> String {
        activeQRKey = nil
        qrSessionCookie = nil
        qrNetworkFailures = 0
        lastQRCodeValue = 0
        // key/create/check 固定走同一条原生路由，不混用临时隧道或旧账号 Cookie。
        let json = try await requestJSON("/login/qr/key", baseURL: nativeBase)
        guard let data = json["data"] as? [String: Any], let key = data["unikey"] as? String, !key.isEmpty else {
            throw APIError(code: (json["code"] as? NSNumber)?.intValue, message: qrMessage(json))
        }
        qrSessionCookie = Self.cleanCookie(json["cookie"] as? String ?? "")
        activeQRKey = key
        return key
    }

    /// 扫码第二步：拿二维码图片（data:image/png;base64,...）
    func qrImage(key: String) async throws -> String {
        guard key == activeQRKey else { throw APIError(code: 800, message: "二维码已刷新，请使用新二维码。") }
        let json = try await requestJSON("/login/qr/create", baseURL: nativeBase,
            query: ["key": key, "qrimg": "true"], cookie: qrSessionCookie)
        guard let data = json["data"] as? [String: Any], let image = data["qrimg"] as? String, !image.isEmpty else {
            throw APIError(code: (json["code"] as? NSNumber)?.intValue, message: qrMessage(json))
        }
        return image
    }

    enum QRState {
        case waiting      // 801
        case scanned      // 802
        case confirmed    // 803
        case expired      // 800
        case retrying(String)
        case failed(String)
    }

    /// 最近一次扫码轮询里网易云给的码（-462 风控等要据此提示「先去浏览器验证」）
    private var lastQRCodeValue = 0
    func lastQRCode() -> Int { lastQRCodeValue }

    /// 扫码第三步：轮询。803 时把 cookie 存下来，后续请求带上。
    func checkQR(key: String) async -> QRState {
        guard key == activeQRKey else { return .expired }
        let json: [String: Any]
        do {
            json = try await requestJSON("/login/qr/check", baseURL: nativeBase,
                query: ["key": key], cookie: qrSessionCookie)
            guard !Task.isCancelled, key == activeQRKey else { return .expired }
            qrNetworkFailures = 0
        } catch {
            guard !Task.isCancelled, key == activeQRKey else { return .expired }
            qrNetworkFailures += 1
            let code = (error as? APIError)?.code
            let httpStatus = (error as? APIError)?.httpStatus
            lastQRCodeValue = code ?? 0
            if (error is URLError || (code.map { $0 >= 500 } ?? false)
                || (httpStatus.map { $0 >= 500 } ?? false)), qrNetworkFailures <= 3 {
                return .retrying("连接中断，正在重试（\(qrNetworkFailures)/3），请勿重复扫码。")
            }
            return .failed((error as? LocalizedError)?.errorDescription ?? "扫码连接失败，请刷新二维码。")
        }
        lastQRCodeValue = Self.responseCode(json) ?? 0
        switch Self.responseCode(json) {
        case 800: return .expired
        case 801: return .waiting
        case 802: return .scanned
        case 803:
            let cookie = Self.cleanCookie(json["cookie"] as? String ?? "")
            if Self.hasLoginCookie(cookie) {
                signInCookie = cookie
                anonymousCookie = nil
                return .confirmed
            }
            return .failed("网易云已确认，但接口没有返回 MUSIC_U 登录凭据，请刷新后重试。")
        default:
            return .failed(qrMessage(json))
        }
    }

    private func qrMessage(_ json: [String: Any]) -> String {
        let code = (json["code"] as? NSNumber)?.intValue
        let text = (json["message"] as? String) ?? (json["msg"] as? String) ?? "未知错误"
        return "code \(code.map(String.init) ?? "none"): \(text)"
    }

    // MARK: - 曲库

    /// 用户歌单列表（含「我喜欢的音乐」）
    func userPlaylists(userId: Int, limit: Int = 1000, offset: Int = 0) async throws -> [MusicCollection] {
        let query = [
            "uid": String(userId), "limit": String(limit), "offset": String(offset),
        ]
        let json: [String: Any]
        do {
            let native = try await getNative("/user/playlist", query: query)
            guard (Self.responseCode(native) ?? 200) == 200,
                  native["playlist"] is [[String: Any]] else {
                throw APIError(code: Self.responseCode(native), message: "歌单接口未返回有效数据。")
            }
            json = native
        } catch {
            if error is CancellationError { throw error }
            json = try await get("/user/playlist", query: query, needsTimestamp: true)
        }
        guard let list = json["playlist"] as? [[String: Any]] else {
            throw APIError(code: Self.responseCode(json), message: "歌单接口未返回有效数据。")
        }
        return list.map { raw in
            let creatorId = (raw["creator"] as? [String: Any]).flatMap { ($0["userId"] as? NSNumber)?.intValue }
            let specialType = (raw["specialType"] as? NSNumber)?.intValue
            let liked = specialType == 5 && creatorId == userId
            return Self.collection(from: raw, kind: .playlist, isLiked: liked)
        }
    }

    /// 收藏的专辑
    func userAlbums(limit: Int = 100, offset: Int = 0) async throws -> [MusicCollection] {
        let json = try await get("/album/sublist", query: ["limit": String(limit), "offset": String(offset)])
        let list = json["data"] as? [[String: Any]] ?? []
        return list.map { Self.collection(from: $0, kind: .album, isLiked: false) }
    }

    /// 每日推荐
    func dailySongs() async throws -> [Song] {
        let json = try await get("/recommend/songs")
        let list = json["data"].flatMap { ($0 as? [String: Any])?["songs"] as? [[String: Any]] } ?? json["songs"] as? [[String: Any]] ?? []
        return list.compactMap(Self.song(from:))
    }

    /// 私人 FM
    func personalFM() async throws -> [Song] {
        let json = try await get("/personal_fm")
        let list = json["data"] as? [[String: Any]] ?? []
        return list.compactMap(Self.song(from:))
    }

    /// 推荐歌单（电台页的推荐位）
    func recommendedPlaylists(limit: Int = 35) async throws -> [MusicCollection] {
        let json = try await get("/personalized", query: ["limit": String(limit)])
        let list = json["result"] as? [[String: Any]] ?? []
        return list.map { Self.collection(from: $0, kind: .radio, isLiked: false) }
    }

    /// 歌单详情
    func playlistDetail(id: Int) async throws -> MusicCollection? {
        let json = try await get("/playlist/detail", query: ["id": String(id)], needsTimestamp: true)
        guard let raw = json["playlist"] as? [String: Any] else { return nil }
        return Self.collection(from: raw, kind: .playlist, isLiked: false)
    }

    /// 歌单全部曲目
    func playlistTracks(id: Int, limit: Int = 1000, offset: Int = 0) async throws -> [Song] {
        let json = try await get("/playlist/track/all", query: [
            "id": String(id), "limit": String(limit), "offset": String(offset),
        ])
        let list = json["songs"] as? [[String: Any]] ?? []
        return list.compactMap(Self.song(from:))
    }

    /// 专辑详情 + 曲目
    func album(id: Int) async throws -> (collection: MusicCollection, songs: [Song])? {
        let json = try await get("/album", query: ["id": String(id)])
        guard let raw = json["album"] as? [String: Any] else { return nil }
        let songs = (json["songs"] as? [[String: Any]] ?? []).compactMap(Self.song(from:))
        return (Self.collection(from: raw, kind: .album, isLiked: false), songs)
    }

    /// 搜索（曲目）
    func search(_ keywords: String, limit: Int = 50, offset: Int = 0) async throws -> [Song] {
        let json = try await get("/cloudsearch", query: [
            "keywords": keywords, "limit": String(limit), "offset": String(offset),
        ])
        let result = json["result"] as? [String: Any] ?? json
        let list = result["songs"] as? [[String: Any]] ?? []
        return list.compactMap(Self.song(from:))
    }

    /// 音频地址。level 为 exhigh 时是 320k；VIP 曲目也通常能拿到签名地址。
    func audioURL(songId: Int, level: String = "exhigh") async throws -> (url: URL, isPreview: Bool) {
        let json = try await get("/song/url/v1", query: [
            "id": String(songId), "level": level, "randomCNIP": "true", "https": "true",
        ])
        guard let first = (json["data"] as? [[String: Any]])?.first else {
            throw APIError(code: (json["code"] as? NSNumber)?.intValue, message: "没有拿到音频地址")
        }
        guard let text = first["url"] as? String, !text.isEmpty else {
            throw APIError(code: (first["code"] as? NSNumber)?.intValue, message: "这首歌暂时没有可播放的音源")
        }
        let https = text.hasPrefix("http://") ? "https://" + text.dropFirst(7) : text
        guard let url = URL(string: https) else {
            throw APIError(code: nil, message: "音频地址无效")
        }
        return (url, first["freeTrialInfo"] is [String: Any])
    }

    // MARK: - 歌词

    func lyrics(songId: Int) async throws -> [LyricLine] {
        let json = try await get("/lyric/new", query: ["id": String(songId)])
        let lrc = (json["lrc"] as? [String: Any])?["lyric"] as? String
            ?? (json["lrc"] as? String)
            ?? ""
        let yrc = (json["yrc"] as? [String: Any])?["lyric"] as? String ?? ""
        return LyricParser.parse(yrc.isEmpty ? lrc : yrc)
    }

    // MARK: - JSON → 模型

    private static func collection(from raw: [String: Any], kind: CollectionKind, isLiked: Bool) -> MusicCollection {
        let artists = (raw["artists"] as? [[String: Any]]) ?? (raw["artist"] as? [String: Any]).map { [$0] } ?? []
        let creator = (raw["creator"] as? [String: Any])?["nickname"] as? String
            ?? artists.first?["name"] as? String
            ?? (raw["artist"] as? [String: Any])?["name"] as? String
        return MusicCollection(
            id: (raw["id"] as? NSNumber)?.intValue ?? 0,
            name: raw["name"] as? String ?? "",
            kind: kind,
            coverUrl: raw["coverImgUrl"] as? String ?? raw["picUrl"] as? String,
            description: raw["description"] as? String ?? raw["briefDesc"] as? String,
            trackCount: (raw["trackCount"] as? NSNumber)?.intValue ?? (raw["size"] as? NSNumber)?.intValue,
            isLiked: isLiked || (raw["isLiked"] as? Bool ?? false),
            creatorName: creator
        )
    }

    /// 对齐 netease.ts 的 normalizeSongResult
    static func song(from raw: [String: Any]) -> Song? {
        let base = raw["simpleSong"] as? [String: Any] ?? raw
        let id = (base["id"] as? NSNumber)?.intValue ?? (raw["id"] as? NSNumber)?.intValue ?? 0
        guard id > 0 else { return nil }

        let artists = (base["ar"] as? [[String: Any]])
            ?? (base["artists"] as? [[String: Any]])
            ?? (raw["artists"] as? [[String: Any]])
            ?? []
        let albumRaw = (base["al"] as? [String: Any]) ?? (base["album"] as? [String: Any]) ?? [:]
        let t = (base["t"] as? NSNumber)?.intValue ?? (raw["t"] as? NSNumber)?.intValue ?? 0

        let privilege = base["privilege"] as? [String: Any] ?? raw["privilege"] as? [String: Any]
        let st = (privilege?["st"] as? NSNumber)?.intValue

        return Song(
            id: id,
            name: base["name"] as? String ?? raw["name"] as? String ?? "未知歌曲",
            artists: artists.enumerated().map { index, artist in
                Artist(
                    id: (artist["id"] as? NSNumber)?.intValue ?? index,
                    name: artist["name"] as? String ?? ""
                )
            }.filter { !$0.name.isEmpty },
            album: Album(
                id: (albumRaw["id"] as? NSNumber)?.intValue ?? 0,
                name: albumRaw["name"] as? String ?? "",
                coverUrl: albumRaw["picUrl"] as? String ?? albumRaw["blPicUrl"] as? String
                    ?? (albumRaw["artist"] as? [String: Any])?["picUrl"] as? String
            ),
            durationMs: (base["dt"] as? NSNumber)?.intValue ?? (base["duration"] as? NSNumber)?.intValue ?? 0,
            isCloud: t == 1 || t == 2,
            fee: (base["fee"] as? NSNumber)?.intValue,
            st: st
        )
    }
}

/// 登录态存 Keychain：cookie 是密码级的东西，不该落在 UserDefaults。
enum Keychain {
    private static let service = "app.folia.major.native"

    static func get(_ key: String) -> String? {
        var query = baseQuery(key)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func set(_ value: String?, for key: String) {
        let query = baseQuery(key)
        if let value, let data = value.data(using: .utf8) {
            SecItemDelete(query as CFDictionary)
            var attributes = query
            attributes[kSecValueData as String] = data
            attributes[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
            SecItemAdd(attributes as CFDictionary, nil)
        } else {
            SecItemDelete(query as CFDictionary)
        }
    }

    private static func baseQuery(_ key: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
        ]
    }
}
